<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>HappyFeet: The next generation of style!</title>

    
    <link href="css/main.css" rel="stylesheet">

   
</head>

<body>
<?php require 'layout/header.php';?>`
<center><h1>HappyFeet: The next generation of style!</h1></center>
<h3>Find out more about of website here</h3>










<?php require 'layout/footer.php';?>
</body>
</html>