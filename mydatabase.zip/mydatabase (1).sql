-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2025 at 09:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `AccountID` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `Password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`AccountID`, `email`, `Password`) VALUES
(19, 'BenC@gmail.com', 'P@ssword'),
(20, 'admin@happyfeet.com', 'adminPass123'),
(21, 'darren@icould.ie', 'iLovePHP'),
(22, 'jason@outlook.com', 'apples4321'),
(23, 'alex@yahoo.ie', 'elephants9'),
(24, 'EvanC4@gmail.com', 'iHatePenguins6');

-- --------------------------------------------------------

--
-- Table structure for table `orderhistory`
--

CREATE TABLE `orderhistory` (
  `OrderID` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `eircode` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderhistory`
--

INSERT INTO `orderhistory` (`OrderID`, `email`, `name`, `eircode`, `date`, `total`) VALUES
(6, 'BenC@gmail.com', 'Ben Cranley', 'C15FG42', '2025-05-04 19:21:06', 110),
(7, 'BenC@gmail.com', 'Ben Cranley', 'C15JU89', '2025-05-04 19:22:26', 184.99),
(8, 'admin@happyfeet.com', 'Admin', 'D08E1W3', '2025-05-04 19:24:56', 149.99),
(9, 'admin@happyfeet.com', 'Admin', 'D08E1W3', '2025-05-04 19:25:20', 355),
(10, 'admin@happyfeet.com', 'Admin', 'D08E1W3', '2025-05-04 19:25:41', 309.99),
(11, 'alex@yahoo.ie', 'Aleksander Byrne', 'C15PWR9', '2025-05-04 19:36:06', 115),
(12, 'alex@yahoo.ie', 'Aleksander Byrne', 'C15PWR9', '2025-05-04 19:40:30', 85),
(13, 'alex@yahoo.ie', 'Aleksander Byrne', 'C15 PWR9', '2025-05-04 19:41:04', 320),
(14, 'BenC@gmail.com', 'Ben Cranley', 'C15GTR3', '2025-05-04 21:24:14', 125);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Description` varchar(250) NOT NULL,
  `Price` double NOT NULL,
  `tags` tinytext NOT NULL,
  `imagePath` varchar(50) NOT NULL,
  `link` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `Name`, `Description`, `Price`, `tags`, `imagePath`, `link`) VALUES
(1, 'Air Force 1', 'The Nike Air Force 1 is a classic leather trainer with a sturdy, simple design and a versatile, casual vibe.', 200, 'Casual', 'images/AirForce1s.jpg', 'Airforce.php'),
(2, 'Adidas Gazelle', 'The Adidas Gazelle is a classic suede trainer with a simple, low-profile design and timeless casual style.', 110, 'Casual', 'images/Gazelle.jpg', 'Gazelle.php'),
(3, 'Batman Crocs', 'The Batman Crocs clogs with the iconic Batman logo, offering a comfy, casual fit with a hint of superhero flair.', 70, 'Casual', 'images/batman.jpg', 'batman.php'),
(4, 'Air Max 90s', 'The Nike Air Max 90 is a timeless trainer with a distinctive design, visible Air cushioning, and all-day comfort.', 149.99, 'Casual', 'images/AirMax90s.png', 'AirMax90s.php'),
(5, 'Adidas Sambas', 'The Adidas Samba is a classic leather trainer with a sleek, retro design and a versatile, casual style.', 120, 'Casual', 'images/Sambas.jpg', 'Sambas.php'),
(6, 'Vans Old Skool', 'The Vans Old Skool is a versatile sneaker with a mix of canvas and suede, featuring the signature side stripe and a casual, retro vibe.', 85, 'Casual', 'images/OldSkool.jpg', 'OldSkool.php'),
(7, 'NB BB550', 'The New Balance BB550 is a retro-inspired sneaker with a durable design, leather upper, and a clean, casual style.', 140, 'Casual', 'images/BB550.jpg', 'BB550.php'),
(8, 'Court Vison Low', 'The Nike Court Vision Low is a sleek, leather sneaker with a simple design and a timeless, everyday style.', 80, 'Casual', 'images/CourtVision.jpg', 'CourtVision.php'),
(9, 'All Star Hi', 'The Converse All Star Hi is a legendary high-top sneaker with a durable canvas upper and a simple, versatile style.', 75, 'Casual', 'images/AllStarHi.jpg', 'AllStarHi.php'),
(10, 'Blazer Low', 'The Nike Blazer Low is a clean, minimalist sneaker with a leather and suede upper, offering a casual, retro-inspired style.', 100, 'Casual', 'images/BlazerLow.jpg', 'BlazerLow.php'),
(11, 'GEL-KAYANO 14', 'The ASICS GEL-Kayano 14 is a retro-inspired running shoe with a supportive, cushioned design and a stylish, sporty look.\r\n\r\n\r\n\r\n', 160, 'Sport', 'images/GEL-KAYANO14.jpg', 'GEL-KAYANO14.php'),
(12, 'NB MR530SG', 'The New Balance MR530SG is a retro-style sneaker with a breathable mesh upper, suede overlays, and a comfortable, sporty design.', 125, 'Sport', 'images/NBMR530SG.jpg', 'NBMR530SG.php'),
(13, 'Nike P-6000s', 'The Nike P-6000 is a stylish, retro-inspired trainer with breathable mesh, and all-day comfort.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 109.99, 'Sport', 'images/P6000s.png', 'P6000s.php'),
(14, 'GEL-Excite 10', 'The ASICS GEL-Excite 10 is a lightweight running shoe with a breathable mesh upper, GEL cushioning, and a comfortable, performance-driven design.', 75, 'Sport', 'images/GEL-Excite10.jpg', 'GEL-Excite10.php'),
(15, 'Pegasus Plus ', 'The Nike Pegasus Plus is a performance-focused running shoe with a lightweight design, responsive cushioning, and excellent support for active wear.', 150, 'Sport', 'images/PegasusPlus.jpg', 'PegasusPlus.php'),
(16, 'Adizero Boston 12 ', 'The adidas Adizero Boston 12 is a lightweight, high-performance running shoe with a responsive midsole, breathable upper, and a sleek, race-ready design.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 160, 'Sport', 'images/AdizeroBoston12.jpg', 'AdizeroBoston12.php '),
(17, 'Fresh Foam 680', 'The New Balance Fresh Foam 680 is a cushioned running shoe with a breathable mesh upper, supportive design, and a focus on comfort for daily runs.', 100, 'Sport', 'images/FreshFoam680.jpg', 'FreshFoam680.php'),
(18, 'Flow Velociti Wind 2', 'The Under Armour Flow Velociti Wind 2 is a lightweight, high-performance running shoe with a seamless design, responsive cushioning, and a focus on speed and agility.', 115, 'Sport', 'images/FlowVelocitiWind2.jpg', 'FlowVelocitiWind2.php'),
(19, 'Supernova Solution 2.0', 'The Adidas Supernova Solution 2.0 is a supportive running shoe with a cushioned midsole, breathable upper, and a focus on comfort and stability for long runs.', 125, 'Sport', 'images/SupernovaSolution2.0.jpg', 'SupernovaSolution2.0.php'),
(20, 'ReactX Pegasus Trail', 'The ReactX Pegasus Trail is a Nike running shoe designed for comfort and durability across both roads and light trails.', 115, 'Sport', 'images/ReactXPegasusTrail.jpg', 'ReactXPegasusTrail.php');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`AccountID`);

--
-- Indexes for table `orderhistory`
--
ALTER TABLE `orderhistory`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `AccountID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orderhistory`
--
ALTER TABLE `orderhistory`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
