<footer>
    <p>&copy; <?php echo date("Y"); ?> HappyFeet. All Rights Reserved.</p>
</footer>
    
