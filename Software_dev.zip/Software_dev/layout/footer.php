<footer>
    <hr>
            <p>&copy; HappyFeet.com</p>
        </footer>
    </div>
    
